***README***
Included are all the source files and the APK for installing the application.
All the source files and images are in the src.

***Installing***
If you have a previous version of the Tolleson app installed on your android device, then uninstall it by going to "Settings>Apps>Tolleson Union High School>Uninstall"
Connect your device to your computer and navigate to where you have your "app-debug.apk" file and move the file onto the SD or Internal Memory of you device. (If your device is not connected in MTP mode you may have some issues moving files)
If you have not installed a previous version of the app then go to "Settings>Security>Unknown Sources" and make sure the "Unknown sources" option is checked.
After checking on "Unknown sources" open up your devices file browser, if you don not have one installed download one from the play store.
Navigate to the folder you put the "app-debug.apk" and then click on it to run the file to install it.